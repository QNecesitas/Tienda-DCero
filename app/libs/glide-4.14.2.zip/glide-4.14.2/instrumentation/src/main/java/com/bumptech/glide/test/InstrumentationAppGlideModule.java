package com.bumptech.glide.test;

import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;

@GlideModule
public class InstrumentationAppGlideModule extends AppGlideModule {
  // Intentionally empty.
}
