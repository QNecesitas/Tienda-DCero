package com.bumptech.glide.test;

import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.LibraryGlideModule;

@GlideModule
public final class EmptyLibraryModule extends LibraryGlideModule {}
