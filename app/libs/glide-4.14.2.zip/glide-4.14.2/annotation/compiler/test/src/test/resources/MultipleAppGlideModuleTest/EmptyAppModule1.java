package com.bumptech.glide.test;

import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;

@GlideModule
public final class EmptyAppModule1 extends AppGlideModule {}