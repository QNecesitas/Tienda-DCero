package com.bumptech.glide.annotation.compiler;

@Index(
    modules = {
        "com.bumptech.glide.test.EmptyLibraryModule1",
        "com.bumptech.glide.test.EmptyLibraryModule2"
    }
)
public class GlideIndexer_GlideModule_com_bumptech_glide_test_EmptyLibraryModule1_com_bumptech_glide_test_EmptyLibraryModule2 {
}
